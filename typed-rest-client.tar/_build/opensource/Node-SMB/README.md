### Reference:
The modules (common.js, ntlm.js and smbhash.js) were copied from a file of the same name at https://github.com/Node-SMB/ntlm.

The modules has been used for the purpose of encoding and decoding the headers used during NTLM HTTP Authentication and as of this writing, it is a part of the typed-rest-client module produced by Microsoft.

